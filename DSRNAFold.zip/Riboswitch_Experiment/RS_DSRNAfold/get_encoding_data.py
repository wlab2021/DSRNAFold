
'''
    Used to obtain npz data packages corresponding to the training set and test set through the encoding model.
'''
import os
import torch
import numpy as np
import argparse
from function import constraint_matrix_CDP, constraint_matrix_batch, travel
import sys
from utils import get_data, get_args_from_json
from ts2vec import TS2Vec

from Layers import PretrainModel, Model
from function import postprocess, normalize_by_threshold, get_bpseq
from torch.utils.data import DataLoader, TensorDataset

def start_predict(seq_list, feature_vector, label_matrix, N, M, limit_length, test_length, device, steps, dropout_rate, normalize_threshold, test_name, batch_size):

    device = torch.device("cpu")
    # device = torch.device(device if torch.cuda.is_available() else "cpu")
    # print('Device number: ', device)
    # print('The total number of samples used for prediction.: ',  int(seq_list.shape[0]))

    feature_vector = torch.from_numpy(feature_vector).float()
    N = torch.from_numpy(N).float()    
    M = torch.from_numpy(M).float()
    label_matrix = torch.from_numpy(label_matrix).float()


    test_dataset = TensorDataset(feature_vector, N, M)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    model_path = './model/{}/ALLtrain.pt'.format(limit_length)

    
    model = Model(PretrainModel(dropout_rate=dropout_rate), limit_length, steps=steps)
    model.load_state_dict(torch.load(model_path))
    model = model.to(device)
    model.eval()

    prediction = []
    for _, data in enumerate(test_loader):
        feature_vector, N, M = data
        feature_vector, N, M = feature_vector.to(device), N.to(device), M.to(device)
        predict = model(feature_vector, N, M)
        predict = predict.cpu().detach().numpy()
        
        # predict = normalize_by_threshold(predict, normalize_threshold)
        # predict = postprocess(predict)
        prediction.extend(predict)

    # get_bpseq(test_length, seq_list, prediction, test_name)
   
    result_length = test_length[0]
    result_seq = []
    

    letter = ['N', 'A', 'U', 'G', 'C']

    for h in range(result_length): 
        result_seq.append(letter[seq_list[0][h]])

    return ''.join(result_seq), prediction[0]

def code_padding(seq, seq_len):
    '''
        word_coder = {
        "A": 1,
        "U": 2,
        "G": 3,
        "C": 4,
    }
    '''
    word_coder = {
        "A": '0001',
        "U": '0010',
        "G": '0100',
        "C": '1000',
        "a": '0001',
        "u": '0010',
        "g": '0100',
        "c": '1000',
    }
    
    seq_ = []
    for i in range(len(seq), seq_len):
        seq.append('N')  
    for i in range(seq_len):
        feature = word_coder.get(seq[i], '0000')
        seq_.append(feature)
      
    return seq_

def get_predict_result(data):

    sequence = data
    seq_len = len(sequence)

    if seq_len <= 128:
        args = get_args_from_json('./args_ALL128.json')
    elif seq_len <= 512:
        args = get_args_from_json('./args_ALL128.json')

    limit_length = args.max_seq_len 
    encoding_model_name = args.encoding_model_name + '-{}'.format(limit_length)
    repr_dim = args.repr_dim

    steps = args.constraint_steps
    dropout_rate = args.dropout_rate
    normalize_threshold = args.normalize_by_threshold
    batch_size = args.batch_size
    # device = args.device
    device = "cpu"

    # torch.cuda.set_device(device)
    # if gpu is to be used
    device = torch.device("cpu")
    # device = torch.device("cuda:{}".format(device) if torch.cuda.is_available() else "cpu")

    model = TS2Vec(
        input_dims=4,
        output_dims=repr_dim
    )

    model.load('./model_file/{}.pth'.format(encoding_model_name))
    # print('model load success')

    length = len(data)
    seq = []
    for i in range(len(data)):
        seq.append(data[i])

    seq_ = code_padding(seq, limit_length)
    seq_list = get_data(np.array(seq_))
    label_matrix = [[0 for _ in range(limit_length)] for _ in range(limit_length)]
    label_matrix = np.array(label_matrix, dtype=int)
    
    length = np.array([length])
    file_name = np.array(['test.bpseq'])

    seq_list = np.expand_dims(seq_list, axis=0)
    label_matrix = np.expand_dims(label_matrix, axis=0)
    data_repr_test = model.encode(seq_list)
    seq_list = travel(seq_list)
    
    N = constraint_matrix_CDP(seq_list)
    M = constraint_matrix_batch(seq_list)
    file_name = np.array(file_name)


    steps = args.constraint_steps
    dropout_rate = args.dropout_rate
    normalize_threshold = args.normalize_by_threshold
    batch_size = args.batch_size
    # device = args.device
    device = "cpu"
    # torch.cuda.set_device(device)
    # if gpu is to be used
    # device = torch.device("cuda:{}".format(device) if torch.cuda.is_available() else "cpu")
    
    seq_list, result_pair_matrix = start_predict(seq_list, data_repr_test, label_matrix, N, M, limit_length, length, device, steps, dropout_rate, normalize_threshold, file_name, batch_size)

    return seq_list, result_pair_matrix


