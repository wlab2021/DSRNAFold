import os
import numpy as np
import pandas as pd
import sys
from get_encoding_data import get_predict_result


EPSILON = 1e-13

def compute_bp_kfold(row, MS2_aptamer):
    seq_list, prediction = get_predict_result(row)
    
    if row == seq_list:
        bp_matrix = prediction
    else:
        print('error in get_predict_result')

    first_base = MS2_aptamer.find('(')
    second_base = MS2_aptamer.rfind(')')

    return bp_matrix[first_base][second_base] + EPSILON


def calculate_and_write_logkd_nolig(input_file, output_file):
    df = pd.read_csv(input_file)

    for index, row in df.iterrows():
        sequence = row['sequence']
        MS2_aptamer = row['MS2_aptamer']
        result = compute_bp_kfold(sequence, MS2_aptamer)
        df.at[index, 'pred_logkd_nolig'] = result
        logK = np.log(ref_structure('GGGUAUGUCGCAGAAACAUGAGGAUCACCCAUGUAACUGCGACAUACCC') / result)
        df.at[index, 'logK_nolig_pred'] = logK

    df.to_csv(output_file, index=False)


def ref_structure(seq):
    seq_list, prediction = get_predict_result(seq)
    if seq == seq_list:
        bp_matrix = prediction
    else:
        print('error in get_predict_result')
    

    return bp_matrix[15][33] + EPSILON



if __name__ == '__main__':

    input_file =  '../RS_data/EternaBench_Riboswitch.csv'
    output_file = '../RS_data/EternaBench_Riboswitch.csv'
    
    calculate_and_write_logkd_nolig(input_file, output_file)

