# This document provides a detailed explanation of the riboswitch validation experiment.

## 1. Predicting without training the model:

### (1). RS_data:

#### 1.EternaBench_Riboswitch.csv: Contains 11 riboswitch datasets with a total of 7107 sequences. It comes from https://github.com/eternagame/EternaBench/data/EternaBench_Riboswitch_Filtered_23May2022.json.zip. so you need to open https://github.com/eternagame/EternaBench/, and then download data/EternaBench_Riboswitch_Filtered_23May2022.json.zip.  The dataset 88-RMN has been excluded as it was not used by other models. The column "logkd_nolig" represents the true values, while "pred_logkd_nolig" and "logK_nolig_pred" represent the predicted values by the model.

#### 2.RS_DSRNAFold_pearson.csv: Contains the Pearson correlation coefficients of the DSRNAFold model on the 11 datasets.

#### 3.RS_Z_pearson_logkd_nolig_zscores.csv: Contains the Pearson correlation coefficients of 12 traditional classical models and DSRNAFold on the 11 datasets.

### (2). RS_DSRNAfold:

#### 1.model_file: A representation model trained using all sequences with lengths up to 128 from `RNAStralign, TR0, and Rfam14`.The model can be obtained from "model/Riboswitch_Experiment/RS_pth/ALLtrain_ALLtest-128.pth" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF. After downloading, you need to put `ALLtrain_ALLtest-128.pth` in Riboswitch_Experiment/RS_DSRNAfold/model_file/ALLtrain_ALLtest-128.pth.

#### 2.model: A prediction model trained using all sequences with lengths up to 128 from `RNAStralign, TR0, and Rfam14`.The model can be obtained from "model/Riboswitch_Experiment/RS_model/128/ALLtrain.pt" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF. After downloading, you need to put `ALLtrain.pt` in Riboswitch_Experiment/RS_DSRNAfold/model/128/ALLtrain.pt.

#### 3.args_ALL128.json: Parameter file. It is located in Riboswitch_Experiment/RS_DSRNAfold/args_ALL128.json. `You don't need to deal with it.` 

#### 4.Running `python get_RS_data.py` will generate the base pair probabilities of the DSRNAFold model on the 7107 sequences. The updated data will be saved in the pred_logkd_nolig and logK_nolig_pred columns of the RS_data/EternaBench_Riboswitch.csv file. The pred_logkd_nolig column represents the base pair probability of the terminal base in the test sequence, while the logK_nolig_pred column represents the logarithm of the ratio between the base pair probability of the terminal base in the reference structure and the test sequence. The base pair probability of the terminal base in the reference structure is 1. The reference structures can be found at https://github.com/eternagame/EternaBench.

#### 5.The RS_cal_coefficient.ipynb notebook calculates the Pearson correlation coefficient for the DSRNAFold model on a dataset-by-dataset basis.

## 2. If you want to train the encoding model and representation model:

#### 1.Data acquisition: Download ALLtrain_ALLtest-128.zip. The data can be obtained from "Data/Riboswitch_Experiment/ALLtrain_ALLtest-128.zip" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

#### 2.After extracting it, place it in the DSRNAFold_code/ts2vec/datasets folder.

#### 3.Place the args_ALL128.json parameter file in the DSRNAFold_code/util folder.

#### 4.Modify the parameter file in DSRNAFold_code/ts2vec/get_encoding_model.py, DSRNAFold_code/RNAfold/code/get_encoding_data.py, DSRNAFold_code/RNAfold/code/pretrain.py, and DSRNAFold_code/RNAfold/code/train.py.

#### 5.Execute the following commands in order:

##### (1) python get_encoding_model.py

##### (2) python get_encoding_data.py

##### (3) python pretrain.py

##### (4) python train.py
