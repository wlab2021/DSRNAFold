## The source code for this project is derived from ts2vec:  https://github.com/zhihanyue/ts2vec

### Please place the json file of the corresponding dataset here.

### Note: When running the .py file, you need to modify it to the json file of the corresponding dataset.

#### The py files to be modified are as follows:

    For RNAseq2vec/ folder:
        
        args = get_args_from_json('../util/args_*.json')
    
        python get_encoding_model.py


    For RNAFold/code:
    
        args = get_args_from_json('../../util/args_*.json')
    
        python get_encoding_data.py
        python pretrain.py
        python train.py
        python predict.py

