# The loss function change curves during pre-training and formal training are stored here

