# The predicted result files will be stored here

    The label folder stores ground truth secondary structure of the RNA sequence.
    
    
    The predict folder stores secondary structure predicted by the model.


