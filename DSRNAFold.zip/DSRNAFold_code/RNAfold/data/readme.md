# The original data demo is located in the ../../ts2vec/datasets folder. Since the encoded data is large, you need to follow the process. The process is as follows:

## Please noting: the parameters of the .py file are set and used in the json file format, so to run different datasets, you need to do the following:

    1. Put the json file of the corresponding datasets into the RNAfold/util folder. The util for Performance experiments is in Performance experiments/Experiment_util, and the util for chemical mapping validation is in Chemical Mapping Activity/CM_Experiment_util. RNA classification experiments and riboswitch experiments do not require operation of util files.

    2.If you want to run a certain dataset, change 
                    args = get_args_from_json('../../util/args_Arc128.json')
     in the .py file you want to run to the json file of the corresponding dataset. For example, if you want to run the RNAStralign-512 dataset, change the line to `args = get_args_from_json('../../util/args_Arc512.json')`.

     Please note the file path. For example, relative to the util folder, the json file path is different in RNAfold/code and ts2vec/.

## After completing the above operations, you can run it in the ts2vec/. Note to modify the json file in get_encoding_model.

        python get_encoding_model.py
    

## Then you can enter RNAfold/code and run. Note to modify the json file in get_encoding_data. Please note that due to the large size of the generated npz file, it is recommended that the host has at least 512GB of memory.

        python get_encoding_data.py

## After the run is complete, the generated npz file is saved in the RNAFold/data/128(or 512) folder.