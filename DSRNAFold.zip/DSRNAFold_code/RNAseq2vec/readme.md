## The source code for this project is derived from ts2vec:  https://github.com/zhihanyue/ts2vec. Based on the characteristics of our research, we made some minor modifications on this basis.


### 1. get_encoding_model.py:
    Train the RNA sequence representation model through the fasta files of the training set and the test set

### 2. model_file folder
    Store the trained RNA sequence representation model .pth file
    (1). RNAStralign_ArchiveII-128.pth, RNAStralign_ArchiveII-512.pth are derived from RNAStralign-ArchiveII datasets.
    (2). TR0_TS0-128.pth, TR0_TS0-512.pth are derived from bpRNA datasets.
    (3). TRpdn_TSpdn-128.pth, TRpdn_TSpdn-512.pth are derived from the bpRNA dataset containing pseudoknot.
    (4). Rfam15train_Rfam15test-128.pth, Rfam15train_Rfam15test-512.pth are derived from the Rfam15train-Rfam15test dataset.
    (5). ECMtrain_ECMtest-128.pth, ECMtrain_ECMtest-512.pth are derived from the Chemical Mapping Activity dataset.

### 3. datasets

    Store RNA sequence training and testing data. For example, RNAStralign_ArchiveII-128 means RNAStralign-128 is the training set and ArchiveII-128 is the test dataset. The length of all sequence data is less than or equal to 128. And all sequence data lengths will be padded to 128 during the encoding process. The naming format of other datasets are similar.

### 4. The above .pth files have been trained. If you want to retrain:

    (1) Get the training and testing dataset and name it according to step 3.
    (2) Get the json file corresponding to the dataset and place it in DSRNAFold_code/util folder.
    
    (3) Modify the args parameter in get_encoding_model.py:
    
            args = get_args_from_json('../util/args_*.json')
    
    (4) run python get_encoding_model.py