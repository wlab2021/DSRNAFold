## Here, the original data in BPSEQ or CT format is placed. 

### The naming rules are as follows:

    For example: 
        
        train_test-128: train dataset and testing dataset folder.
        train_test-128/train-128:  train dataset.
        train_test-128/test-128:  test dataset.
        
        train_test-512: train dataset and testing dataset folder.
        train_test-512/train-512:  train dataset.
        train_test-512/test-512:  test dataset.


### Note:

#### 1. The data in the current two data folders(train_test-128, train_test-512) are Demo datasets. So the prediction results are not reliable. 

#### 2. The complete data link is https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF. You can get it in Data/Performance/.
