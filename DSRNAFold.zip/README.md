# DSRNAFold

## Web server

#### A web server is working at [DSRNAFold](http://123.60.79.219:5000) online platform. Please check it out!!! 

## The project includes six folders(or files):

#### 1. readme_json_file.md: Details of the model parameter files `.json` are described in detail, `it's important`.

#### 2. DSRNAFold_code: The experimental code for the DSRNAFold project is included in the repository. Here is the main code.


#### 3. RNA Classification: It includes the section on RNA species classification and RNA family classification tasks mentioned in the paper.

#### 4. Performance experiments: It includes the sections on Archive II, TS0, Pseudoknot experiments and generalization experiments mentioned in the paper.

#### 5. Chemical Mapping Activity: It includes the validation section of the chemical mapping experiments mentioned in the paper.

#### 6. Riboswitch_Experiment: It includes the validation section of the Riboswitch_Experiment experiments mentioned in the paper.

## Note:

#### Each corresponding folder for each section contains its own readme file. If you're interested, you can take a look at them.

