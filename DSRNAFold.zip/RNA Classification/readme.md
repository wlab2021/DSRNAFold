# Data Source:

### 	From RNAStralign dataset, note that length filtering has been applied here. The data encoding models are representation models trained on the RNAStralign and ArchiveII datasets.

## 	RNA Species classification 

#### 		Species classification I:5S ribosomal RNA.

#### 		Species classification II: 16S ribosomal RNA.

## 	RNA Family classification

#### 		RNA Family classification I:5S ribosomal RNA, SPR, tRNA.

#### 		RNA Family classification II: RNaseP, SRP, telomerase, tmRNA.

# How Use:

### 1. To download the four data files in the "Data/RNA Classification" folder, please open the following link: https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF. Then place the four data files in the downloaded DSRNAFold_code/RNAfold/RNAseq2vec/datasets/RNA_Classification directory. Note that you need to create the "RNA_Classification" directory yourself.  Please make sure the four datasets folder paths are RNAseq2vec/datasets/RNA_Classification/. After the download is complete, you need to use commands such as unzip, mv, rm -r, etc.The final data path is
    RNAseq2vec/datasets/class/5S ribosomal RNA
    RNAseq2vec/datasets/class/16S ribosomal RNA
    RNAseq2vec/datasets/class/class_5SrRNA_SPR_tRNA
    RNAseq2vec/datasets/class/class_RNaseP_SRP_telomerase_tmRNA

### 2. To obtain a classification image, simply run the code. The code to run the species classification is `python get_class_data_species.py`. The code to run the family classification is `python get_class_data_family.py`. Please note that by changing the limit_length parameter(128 or 512) in the above two py files, different classification images can be obtained.

##  RNA Species classification:

### 	In the case of the 128 categories, the folders 0, 1, 2, 3, and 4 correspond to the following classifications:

#### 	0 folder: 'Archaea'

#### 	1 folder: 'Bacteria'

#### 	2 folder: 'Eukaryota'

#### 	3 folder: 'Mitochondria'

#### 	4 folder: 'Plastids'

### 	For the 512 categories, the folders 0, 1, 2, and 3 correspond to the following classifications:

#### 	0 folder: 'Actinobacteria'

#### 	1 folder: 'Alphaproteobacteria'

#### 	2 folder: 'Aquifcae'

#### 	3 folder: 'Bacilli'

## RNA Family classification:

### 	In the case of the 128 categories, the folders 0, 1, and 2 correspond to the following family classifications:

#### 	0 folder: '5Sr RNA'

#### 	1 folder: 'SPR'

#### 	2 folder: 'tRNA'

### 	For the 512 categories, the folders 0, 1, 2, and 3 correspond to the following family classifications:

#### 	0 folder: 'RNaseP'

#### 	1 folder: 'SRP'

#### 	2 folder: 'telomerase'

#### 	3 folder: 'tmRNA'
