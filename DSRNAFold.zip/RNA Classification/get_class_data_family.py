import numpy as np
import pandas as pd
import os
import shutil
import sys
sys.path.insert(0, '../DSRNAFold_code/util')
from ts2vec import TS2Vec
from utils import get_seq_table, get_data
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

def tsne(data, labels, target_names, family_name):

    X = data
    y = labels
    tsne = TSNE(n_components=2, random_state=42)
    X_tsne = tsne.fit_transform(X)
    plt.figure(figsize=(8, 6))
    for i in range(len(target_names)):
        plt.scatter(X_tsne[y == str(i), 0], X_tsne[y == str(i), 1], label=target_names[i], marker=".", alpha=0.8)
    plt.grid(alpha=0.3)
    plt.title('{}'.format(family_name), fontsize=16)

    plt.xticks(fontsize=16)
    plt.yticks(fontsize=16) 
    plt.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0), fontsize=14)  
    plt.savefig('{}.svg'.format(family_name), dpi=300, bbox_inches='tight') 
    plt.show()


def main(root_path, limit_length, name):

    if limit_length == 128:
        
        family_name = 'RNA Family Classification I'
        target_names = ['5Sr RNA', 'SPR', 'tRNA']
        data = '{}/datasets/RNA_Classification/class_5SrRNA_SPR_tRNA'.format(root_path)

    elif limit_length == 512:
        family_name = 'RNA Family Classification II'
        target_names = ['RNaseP', 'SRP', 'telomerase', 'tmRNA']
        data = '{}/datasets/RNA_Classification/class_RNaseP_SRP_telomerase_tmRNA'.format(root_path)

    else:
        print('Please input the correct limit_length!!!')


    all_class = os.listdir(data)

    seq, label = [], []

    model = TS2Vec(
        input_dims=4,
        output_dims=20
    )

    model.load('model_file/{}.pth'.format(name))
    print('model load success')

    for i in range(len(all_class)):

        train_seq_list, _, _ = get_seq_table(os.path.join(data, all_class[i]), limit_length)
        train_seq_list = get_data(np.array(train_seq_list))
        data_repr_train = model.encode(train_seq_list, encoding_window='full_series')

        seq.extend(data_repr_train)
        label.extend(all_class[i] * train_seq_list.shape[0])

    # Convert lists to numpy arrays
    seq = np.array(seq)
    label = np.array(label)


    # print(train_seq.shape, train_label.shape, test_seq.shape, test_label.shape)
    tsne(seq, label, target_names, family_name)



if __name__ == "__main__":
    
    limit_length = 128 # 128 512
    name = 'RNAStralign_ArchiveII-{}'.format(limit_length)
    
    root_path = '../DSRNAFold_code/RNAseq2vec/'
    main(root_path, limit_length, name)