# Introduction:

### 	This data source is derived from RNA secondary structure packages evaluated and improved by high-throughput experiments (https://github.com/eternagame/EternaBench). The term "reactivity" refers to the reactivity levels of nucleotidesobtained through chemical mapping experiments conducted by the research team mentioned in the paper. The paper demonstrates through deduction that thereis a positive correlation between nucleotide reactivity and the probability of nucleotide mispairing. Therefore, this paper utilizes this data for model validation.

# Preprocessing:

### 	1. Place the data into the path DSRNAFold_code/RNAseq2vec/datasets. The data can be obtained from "Data/Chemical Mapping Activity/CM_Experiment_data" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	2. Put the models from the Chemical Mapping Activity/CM_Experiment_pth" folder in the path 	DSRNAFold_code/RNAseq2vec/model_file. The model can be obtained from "model/Chemical Mapping Activity /CM_Experiment_pth" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	3. Move the models from the "128" folder in the "model" directory to the path DSRNAFold_code/RNAfold/mode/128. Move the models from the "512" folder in the "model" directory to the path DSRNAFold_code/RNAfold/mode/512. The model can be obtained from "model/Chemical Mapping Activity /CM_Experiment_model" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	4. Put the json files from the "Chemical Mapping Activity/CM_Experiment_util" folder in the path DSRNAFold_code/util.

# How Use:

## If you want to directly obtain Pearson correlation coefficients and Z-scores:

### 	1. Rename the "rea_data/predict" folder as "ECM" and place it in the DSRNAFold_code/RNAfold/ directory.The data can be obtained from "Data/Chemical Mapping Activity/CM_Experiment_rea_data/predict" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	2.Rename the "rea_data/label" folder as "EternaBench_ChemMapping_rea_test" and place it in the DSRNAFold/RNAfold/ directory. The data can be obtained from "Data/Chemical Mapping Activity/CM_Experiment_rea_data/label" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	3. Put the Chemical Mapping Activity/CM_Experiment_code/ECM.py files in the code folder into the DSRNAFold_code/RNAfold/ directory.

### 	4. Manually change the value of "file" to Round00-Round23 sequentially, and after making the changes, run the command "`python ECM.py`". This will give you the Pearson correlation coefficients and Z-scores for the predicted base pairing probabilities and base reactivities of this model.

## If you want to retrain the model:

### 	1. Replace the args parameters in DSRNAFold_code/RNAfold/code/get_encoding_data.py, pretrain.py, train.py, and predict.py with the corresponding json file for the dataset.

### 	2. Change constraint_steps to 16.

### 	3. Run `python get_encoding_data.py` to obtain the npz files for the training and testing sets. Store them in the DSRNAFold_code/RNAfold/data directory. Note that you should change the whether_pack_train and whether_pack_test parameters in the json file to true.

### 	4. Run `python pretrain.py` to obtain the pretrained model.

### 	5. Run `python train.py` to train the model. 

### 	6. Create an "ECM" folder in the DSRNAFold_code/RNAfold/ directory. Uncomment the cal_CM_person function in predict.py and comment out lines 53 and 54.Run python predict.py to obtain the reactivity data for the predicted dataset. Note that you need to run it separately for dataset lengths of 128 and 512.

### 	7. Divide the obtained reactivity data into groups labeled Round00-Round23 based on the rounds. Create folders named Round XX and place the 24 Round files in the DSRNAFold_code/RNAfold/ECM folder.

### 	8. Rename the rea_data/label folder as EternaBench_ChemMapping_rea_test and place it in the DSRNAFold_code/RNAfold/ directory. The data can be obtained from "Data/Chemical Mapping Activity/CM_Experiment_rea_data/label" in the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF.

### 	9. Put the Chemical Mapping Activity/CM_Experiment_code/ECM.py files in the code folder into the DSRNAFold_code/RNAfold/ directory.

### 	10. Manually change the value of the "file" variable to Round00-Round23 one by one. After making the changes, run `python ECM.py` to obtain the Pearson correlation coefficient and Z-score for the nucleotide mispairing probability and reactivity predicted by this model.
