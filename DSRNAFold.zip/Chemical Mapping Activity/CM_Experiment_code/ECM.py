from scipy.stats import pearsonr
import pandas as pd
import numpy as np
import math
import os

def calculate_pearson(x, y):
    
    """Calculate Pearson correlation coefficient between two arrays."""
    correlation_coefficient, p_value = pearsonr(x, y)
    
    return correlation_coefficient


def get_perason_mean_std(pearson_corrs):

    # Calculate the mean of the pearson correlations
    pearson_mean = pd.Series(pearson_corrs).mean()
    pearson_std = pd.Series(pearson_corrs).std()

    return pearson_mean, pearson_std

def pearson_to_z(r):

    return 0.5 * math.log((1 + r) / (1 - r))

def get_z_scores_mean_std(z_scores):

    return pd.Series(z_scores).mean(), pd.Series(z_scores).std()

def get_reactivity(file_path):
    
    """Get reactivity from bpseq file."""
    length = 0
    sequence = []
    reactivity = []
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for i in range(len(lines)):
            sequence.append(lines[i].split(' ')[1])
        for line in lines:
            value = line.split(' ')[2].split('\n')[0]
            if value != '-1':
                length += 1
                reactivity.append(float(value))
            else:
                break
        f.close()
        
    return length, ''.join(sequence), reactivity

def get_probability_file(sequence, path):

    num = os.listdir(path)
    id = ''
    seq_ = ''
    for i in range(len(num)):
        seq = []
        with open(os.path.join(path, num[i]), 'r') as f:
            lines = f.readlines()
            for j in range(len(lines)):
                seq.append(lines[j].split(' ')[1])
            seq_ = ''.join(seq)
            f.close()
        if seq_ == sequence:
            id = num[i]
            break
    return id

def get_probability(length, file_path):
    
    """Get probability from bpseq file."""
    probability = []
    with open(file_path, 'r') as f:
        lines = f.readlines()[:length]
        for line in lines:
            probability.append(float(line.split(' ')[2]))
        f.close()
    
    return probability

file = 'Round 23'
path_probability = 'ECM//{}'.format(file)
path_reactivity = 'EternaBench_ChemMapping_rea_test//{}'.format(file)


file_num = os.listdir(path_reactivity)

min_correlation_coefficient = 1
max_correlation_coefficient = -1

cc = []

for i in range(len(file_num)):
    
        length, sequence, reactivity = get_reactivity(os.path.join(path_reactivity, file_num[i]))
        probability_file_id = get_probability_file(sequence, path_probability)
        probability = get_probability(length, os.path.join(path_probability, probability_file_id))
        # print(len(reactivity), len(probability))
        correlation_coefficient = calculate_pearson(reactivity, probability)
        min_correlation_coefficient = min(min_correlation_coefficient, correlation_coefficient)
        max_correlation_coefficient = max(max_correlation_coefficient, correlation_coefficient)
        cc.append(correlation_coefficient)
        
        # print(correlation_coefficient)

print(min_correlation_coefficient, max_correlation_coefficient)

z_scores = [pearson_to_z(r) for r in cc]

# print(z_scores)
# print(min(z_scores), max(z_scores))

print('the person mean std: ', get_perason_mean_std(cc))

print('the z_score mean std: ', get_z_scores_mean_std(z_scores))


df = pd.DataFrame({
        'person': cc,
        'Z_scores': z_scores,
        })

df.to_excel('{}.xlsx'.format(file), index=False)