## If you want to use the json file directly
    1.We provide two groups of demo data: test-128 and test-512.
    2.The json file corresponding to the demo data can be used directly.For example, if you want to run RNAStralign_ArchiveII-512, change the args parameter in DSRNAFold_code/RNAseq2vec/get_encoding_model.py,  DSRNAFold_code/RNAfold/code/get_encoding_data.py, DSRNAFold_code/RNAfold/code/pretrain.py, DSRNAFold_code/RNAfold/code/train.py, RNAfold/code/predict.py to ('../../util/args_Arc512.json').
    3.For performance experiments:
        RNAStralign_ArchiveII-128
        RNAStralign_ArchiveII-512
        TR0_TS0-128
        TR0_TS0-512
        TRpdn_TSpdn-128
        TRpdn_TSpdn-512
        Rfam15train_Rfam15test-128
        Rfam15train_Rfam15test-512 
    The corresponding json file is in Performance experiments/Experiment_util，you need to place it to DSRNAFold_code/util, then you need to modify the args parameter in the corresponding .py file and complete the run.
        (1) in DSRNAFold_code/RNAseq2vec:
            python get_encoding_model.py
        (2) in DSRNAFold_code/RNAfold/code:
            python get_encoding_data.py
            python pretrain.py
            python train.py
            python predict.py
    
        For more details, you can read Performance experiments/readme.md
    
    4. For Chemical Mapping Activity:
        you can read Chemical Mapping Activity/readme.md
    
    5. For Riboswitch_Experiment:
        you can read Riboswitch_Experiment/readme.md
    
    6. For RNA Classification：
        you can read RNA Classification/readme.md




## If you want to modify the parameters of the json file

### The following explains the meaning of each parameter in the json file to facilitate your parameter adjustment.

    1."max_seq_len":Maximum length of training and test sets for RNA seq data after padding.
    
    2."encoding_model_name":The name of the representation model obtained by training and testing data.
    
    3."pretrain_data":Pre-trained dataset name.
    
    4."pretrain_model_name":The name of the pre-trained model obtained by training data.
    
    5."save_loss_for_pretrain":Storage path of the loss function curve change graph during pre-training.
    
    6."train_data": Training dataset name.
    
    7."save_train_model_dir": The name of the folder where the model obtained through formal training.
    
    8."save_loss_for_train":Storage path of the loss function curve change graph during training.
    
    9."test_data": "ArchiveII":Test dataset name.
    
    10."start_test_model_id":Select the starting id of the model when testing data.
    
    11."end_test_model_id":Select the Endding id of the model when testing data.
    
    12."device":cuda device number.
    
    13."batch_size": Batch size.
    
    14."accum_steps": avoid excessive loss values ​​and perform loss function clipping.
    
    15."train_batch_size":Batch size for training.
    
    16."train_accum_steps":During training, avoid excessive loss values ​​and perform loss function clipping.
    
    17."pre_batch_size": Batch size for pre-training.
    
    18."pertrain_epochs": The number of iterations of the pre-training process.
    
    19."train_epochs": The number of iterations of the training process.
    
    20."lr": learning rate.
    
    21."train_lr": The learning rate during training.
    
    22."get_bpseq_file": Whether to obtain the secondary structure file of the predicted RNA sequence.
    
    23."whether_pack_train":Whether to obtain the .npz file of the training dataset for subsequent model training.
    
    24."whether_pack_test":Whether to obtain the .npz file of the testing dataset for subsequent model testing.
    
    25."file_path":The original fasta data storage path. This parameter is not used.
    
    26."file_type": Secondary structure file type of training data.
    
    27."repr_dim":The number of dimensions of RNA sequence representation. please ignore.
    
    28."cut_min_len": RNA sequence cropping lower limit.
    
    29."cut_max_len": RAN sequence cropping upper limit.
    
    30."encoding_model_epochs": The number of iterations of RNA sequence representation model training.
    
    31."if_add_CDP_constraint": Whether to consider improved CDP constraints.
    
    32."seed": Random seed number.
    
    33."dropout_rate": dropout rate.
    
    34."normalize_by_threshold":Base pairing probability threshold.
    
    35."pos_weight":Positive sample weights in the formal training process.
    
    36."constraint_steps":constraint The number of iterations of the hard constraint process. 