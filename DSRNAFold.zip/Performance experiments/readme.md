## 	This section includes three experiments mentioned in the text: RNAStralign (ArchiveII), TR0 (TS0), Pseudoknot (Derived from bpRNA) and Rfam15train(Rfam15test).

# Preprocessing:

### 	1. Download 8 data files from the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF in the folder data/Performance/performance_experiment_data. Then place the 8 data files into the DSRNAFold_code/RNAseq2vec/datasets directory.

### 	2. Download 2 model directory from the link https://drive.google.com/drive/folders/1Jk9e-gTk1xlpYomsDCJ9OyCJD0aFXJQF in the folder model/Performance/. Then place the 128 folder from the into the DSRNAFold_code/RNAfold/model/128 directory, place the 512 folder from the into the DSRNAFold_code/RNAfold/model/512 directory.

### 	3. Place the 8 JSON files from the Performance experiments/Experiment_util  folder into the DSRNAFold_code/util directory.

# Model prediction:

### 	1.If you want to directly perform model prediction, modify the "whether_pack_train" field in the corresponding json file of the dataset to "false", and change the "whether_pack_test" field to "true". Run the command `python get_encoding_data.py` to obtain the NPZ file for the test set.

### 	2.Replace the "args" parameter in DSRNAFold_code/RNAfold/code/predict.py with the corresponding json file of the dataset. Run the command `python predict.py` to complete the prediction.

#  Model training:

### 	1.Replace the "args" parameter in the files DSRNAFold_code/RNAfold/code/get_encoding_data.py, pretrain.py, train.py, and predict.py with the corresponding  json file of the dataset.

### 	2. Run the command: ` get_encoding_data.py`to obtain the NPZ files for the training and test sets. These files will be stored in the DSRNAFold_code/RNAfold/data/128 (or 512) directory.

### 	3. Run the command  `python pretrain.py` to perform pretraining.

### 	4. Run the command `python train.py`to perform training.

### 	5. Run the command`python predict.py`to perform prediction.

### 	6. If you want to obtain the corresponding BPSEQ files for the test set, change the `get_bpseq_file` field in the json file to "true". The predicted files will be stored in the DSRNAFold_code/RNAfold/result/predict directory.

# Note

### 	The loss function curve of the training process is stored in the directory DSRNAFold_code/RNAfold/logs/128 (or 512).
